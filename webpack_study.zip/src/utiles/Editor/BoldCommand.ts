import { Command } from './Commad';

export class BoldCommand implements Command {
  private readonly range: Range;
  private readonly originalContent: string;
  private element: HTMLElement;

  constructor(private editorRef: React.RefObject<HTMLDivElement>) {
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) throw new Error('No selection');

    this.range = selection.getRangeAt(0).cloneRange();
    this.originalContent = this.range.cloneContents().textContent || '';

    this.element = document.createElement('strong');
    this.element.textContent = this.originalContent;
  }

  execute() {
    this.range.deleteContents();
    this.range.insertNode(this.element);
  }

  undo() {
    if (this.element.parentNode) {
      const text = document.createTextNode(this.originalContent);
      this.element.parentNode.replaceChild(text, this.element);
    }
  }
}

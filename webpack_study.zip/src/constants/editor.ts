export const COLOR_LIST = [
  { label: '검정', value: '#000000' },
  { label: '빨강', value: '#FF0000' },
  { label: '파랑', value: '#0000FF' },
  { label: '초록', value: '#00FF00' },
] as const;

// Heading 종류 리스트
// const HEADING_LIST = [
//   { label: '본문', value: 'p' },
//   { label: '제목 1', value: 'h1' },
//   { label: '제목 2', value: 'h2' },
//   { label: '제목 3', value: 'h3' },
//   { label: '제목 4', value: 'h4' },
// ] as const;
